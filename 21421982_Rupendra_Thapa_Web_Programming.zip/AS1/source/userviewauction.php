<?php
//checking if session exist, if not then start
if (!isset($_SESSION)) {
    session_start();
}
require('userlayout.php');
?>

<main>
    <article>
        <div class="article-section">
            <table id="customtable">
                <thead>
                    <b>
                        <td>S.N</td>
                    </b>
                    <td>Title</td>
                    <td>Image</td>
                    <td>Action</td>

                </thead>
                <?php
                $user = $pdo->prepare("SELECT * FROM users WHERE id=".$_SESSION['user']);
                $user->execute();
                $user_data = $user->fetch();
                //selecting list of auction with queries using pdo
                $auction_db = $pdo->prepare("SELECT * FROM auction WHERE created_by= '" .$user_data['name'] ."'");

                $auction_db->execute();
                //looping categories in list
                foreach ($auction_db as $i => $auction) { ?>
                    <tr>
                        <td> <?php echo ($i + 1); ?> </td>
                        <td> <?php echo '<img src="data:image/jpeg;base64,'.base64_encode($auction['image'] ).'" width="40px"/>';?></td>
                        <td><?php echo ($auction['title']); ?></td>

                        <td> <a href="editAuction.php?id=<?php echo ($auction['id']) ?>">Edit</a> || <a href="deleteAuction.php?id=<?php echo ($auction['id']) ?>">Delete</a></td>
                    </tr>
                <?php
                }
                ?>

            </table>
        </div>
        </form>
    </article>
</main>

<style>
     #customtable {
        font-family: Arial, sans-serif;
        font-size: 22px;
        border-collapse: collapse;
        width: 100%;
    }

    #customtable td,
    #customtable th {
        border: 1px solid #ddd;
        padding: 9px;
    }

    #customtable tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    #customtable tr:hover {
        background-color: #ddd;
    }

    #customtable th {
        padding-top: 10px;
        padding-bottom: 10px;
        text-align: left;
        background-color: #04AB6D;
        color: white;
    }

</style>