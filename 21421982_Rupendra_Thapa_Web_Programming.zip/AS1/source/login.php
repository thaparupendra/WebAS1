<?php
$pdo = new pdo("mysql:host=db;dbname=web", 'root','password');
session_start();

//checking if session exist
if (isset($_SESSION['user'])) {
    session_destroy();
    header('Location:login.php');
}

//checking if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["email"];
    $password = $_POST["password"];
    //executing query and fetching from database
    $sqlstmt = $pdo->query("select * from users where email='" . $username . "'");
    $sqlstmt->execute();
    $data = $sqlstmt->fetch();
//if data not exist
    if(!$data){
        echo '<script> alert("Incorrect Password");  </script>';
    }
    else{
//validating user and creating session with logged in
        if ($username==$data["email"] && password_verify($password, $data['password']) && $data["type"] == "admin") {
            $_SESSION['admin'] = $data['id'];
            header('Location:adminindex.php');
        
        } elseif ($username==$data["email"] && password_verify($password, $data['password']) && $data["type"] == "user") {
            $_SESSION['user'] = $data['id'];
            header('Location:userindex.php');
        } else {
            echo "username or password incorrect";
        }
    }
   
}
if(isset($_GET['message'])){
    echo '<script> alert("Please Login to Read More");  </script>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <link rel="stylesheet" href="ibuy.css">
  <link rel="stylesheet" href="login-register.css">
</head>
<body>

<form action="#" method="POST">
  <div class="container">
    <h1>Login</h1>
    <p>Please login to enter.</p>
    <hr>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" id="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" id="psw" required>

    
    <hr>

    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
    <button type="submit" class="registerbtn">Login</button>
  </div>

  <div class="container signin">
    <p>Create Account <a href="register.php">Sign up</a>.</p>

    <p>Back to Home <a href="index.php">Home</a>.</p>
  </div>
</form>
</body>
</html>

