<?php
//checking if session exist, if not then start
if (!isset($_SESSION)) {
    session_start();
}
require('adminLayout.php');
?>

<main>
    <article>
        <div class="article-section">
            <table id="customtable">
                <thead>
                    <b>
                        <td>S.N</td>
                    </b>
                    <td>Title</td>
                    <td>Image</td>
                    <td>Action</td>

                </thead>
                <?php
                //selecting categories queries using pdo
                $auction_db = $pdo->prepare("SELECT * FROM auction");

                $auction_db->execute();
                //looping categories in list
                //Reference: Arian FaurtoshArian Faurtosh 17.8k2121 gold badges7575 silver badges115115 bronze badges (1960) PHP display image blob from mysql, Stack Overflow. Available at: https://stackoverflow.com/questions/20556773/php-display-image-blob-from-mysql (Accessed: May 5, 2023). 
                foreach ($auction_db as $i => $auction) { ?>
                    <tr>
                        <td> <?php echo ($i + 1); ?> </td>
                        
                        <td> <?php echo '<img src="data:image/jpeg;base64,'.base64_encode($auction['image'] ).'" width="40px"/>';?></td>
                        <td><?php echo ($auction['title']); ?></td>

                        <td> <a href="editAuction.php?id=<?php echo ($auction['id']) ?>">Edit</a> || <a href="deleteAuction.php?id=<?php echo ($auction['id']) ?>">Delete</a></td>
                    </tr>
                <?php
                }
                ?>

            </table>
        </div>
        </form>
    </article>
</main>