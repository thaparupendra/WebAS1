<?php
//checking if session exist, if not then start
if (!isset($_SESSION)) {
    session_start();
}
//requiring layout 
require('adminlayout.php');
//checking for form submit through POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //statement to insert into database
    $row = $pdo->prepare("INSERT INTO categories SET name=:name");
    if ($row->execute($_POST)) {
        echo '<script> alert("Category Added"); </script>';
    } else {
        echo '<script> alert("Category not Add"); </script>';
    }
}
?>

<main>
    <div>
        <h1> Add Category Here </h1><br>
    </div>

    

    <div class="container">
        <form method="POST" action="">

            <div class="">
                <label>Category Name</label><br>
                <input type="text"  placeholder="Category Name" name="name" required>

                <input type="submit" class="submit" value="Submit">
            </div>


        </form>
    </div>

</main>