<?php
//checking if session exist, if not then start
if (!isset($_SESSION)) {
    session_start();
}
if (isset($_SESSION['user'])) {
    include('userlayout.php');

} else {
    include('adminlayout.php');
}
//statement to select category for edit and executing through GET method by its id
$sel_stmt = $pdo->prepare("SELECT * FROM auction where id = :id");
$sel_stmt->execute($_GET);
//fetching the record
$row = $sel_stmt->fetch();

//checking for form submit through post method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
//updating seleted record
    // $sel_stmt = $pdo->prepare("UPDATE categories SET name=:name WHERE id=".$row['id']);
    $sel_stmt = $pdo->prepare("UPDATE auction SET title=:title, description=:description, categoryId=:categoryId, endDate=:endDate, price=:price WHERE id=".$row['id']);
    if ($sel_stmt->execute($_POST)) {
        echo '<script> alert("Category edited"); </script>';
    } else {
        echo '<script> alert("Category Failed to edit"); </script>';
    }
}

?>


<main>
<div class="">
                    <h1> Edit Auction </h1>
                </div>
    <article>
        <div class="article-section">
            <form method="POST" action="">
                
                <div class="">
                <label>Auction title</label><br>
                <input type="text" placeholder="Auction Title" value="<?php echo($row['title']); ?>"" name="title" required>

                <label>Auction description</label><br>
                <textarea placeholder="Auction description" rows="5" cols="3" name="description" required> <?php echo($row['description']); ?>" </textarea>

                <label>Auction Category</label><br>
                <select name="categoryId" id="">
                
                   
                <?php 
                        $stmt = $pdo->prepare("SELECT * FROM categories");
                        $stmt->execute();
                        //looping all categories and placing in option
                        foreach($stmt as $item){
                            ?>

                             <option value="<?php echo ($item['id']) ?>" <?php if($item['id']==$row['categoryId']){ echo 'selected';}  ?> ><?php echo($item['name']) ?></option>
                    <?php
                        }
                    ?>    
                   
                </select>

                

                <label>Auction End Date</label><br>
                <input type="date" placeholder="Auction Date" value="<?php echo($row['endDate']); ?>" name="endDate" required>
                
                <label>Auction Bid Price</label><br>
                <input type="number" placeholder="Auction Bid Price" value="<?php echo($row['price']); ?>" name="price" required>

                <input type="submit" class="submit" value="Submit">
                </div>

        </div>
        </form>
    </article>
</main>