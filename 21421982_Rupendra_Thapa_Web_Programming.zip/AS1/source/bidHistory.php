<?php
//checking if session exist, if not then start
if (!isset($_SESSION)) {
    session_start();
}
require('adminLayout.php');
?>

<main>
    <article>
        <div class="article-section">
            <table id="customtable">
                <thead>
                    <b>
                        <td>S.N</td>
                    </b>
                    <td>Bid By</td>
                    <td>Auction</td>
                    <td>Price</td>
                    <td>Status</td>

                </thead>
                <?php
                //selecting categories queries using pdo
                $auction_db = $pdo->prepare("SELECT * FROM user_bids");

                $auction_db->execute();
                //looping categories in list
                foreach ($auction_db as $i => $auction) { ?>
                    <tr>
                        <td> <?php echo ($i + 1); ?> </td>
                        <td> 
                        <?php
                        //selecting users by using relationship with user_bids table
                            $user = $pdo->prepare("SELECT * FROM users where id=". $auction['user_id']);
                            $user->execute();
                            $user = $user->fetch();
                            echo $user['name'];
                        ?></td>
                        <td><?php 
                        $stmt = $pdo->prepare("SELECT * FROM auction where id=". $auction['auction_id']);
                        $stmt->execute();
                        $stmt = $stmt->fetch();
                        echo ($stmt['title']); ?></td>
                        <td><?php echo $auction['bid_amount'] ?></td>
                        <td>Pending</td>
                    </tr>
                <?php
                }
                ?>

            </table>
        </div>
        </form>
    </article>
</main>