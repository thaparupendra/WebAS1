<?php
session_start();
include('userlayout.php');

//getting latest top 10 auction from database
$auctions = $pdo->prepare("SELECT * FROM auction ORDER BY id DESC LIMIT 10");
$auctions->execute();


?>
<main>
<a href="userviewauction.php" style="font-size: 20px;" > View Your Auction Here</a> &nbsp; &nbsp; &nbsp;|| &nbsp; &nbsp; &nbsp; <a href="useraddAuction.php" style="font-size: 20px;" > Add New Auction</a>
	<h1>Latest Listings / Latest Top 10 Auction</h1>
	
<br>
	<ul class="productList">
		<?php
		foreach ($auctions as $key => $auction) {
		?>
			<li>
				<?php echo '<img src="data:image/jpeg;base64,' . base64_encode($auction['image']) . '" width="600"/>'; ?>
				<article>
					<h2><?php echo $auction['title'];  ?></h2>
					<?php
					//getting category from auction category id
					$category = $pdo->prepare("SELECT * FROM categories where id=" . $auction['categoryId']);
					$category->execute();

					//fetching the record
					$row = $category->fetch();
					?>
					<h3><?php echo $row['name']; ?></h3>
					<p><?php echo $auction['description'];  ?>

					<p class="price">Current bid: £ <?php echo $auction['price'];  ?></p>
					<a href="auction.php?auction_id=<?php echo $auction['id'] ?>" class="more auctionLink">More &gt;&gt;</a>
				</article>
			</li>
		<?php
		}
		?>


	</ul>

	<hr />


	<?php
	include('footer.php');
	?>