<?php
//checking if session exist, if not then start
if (!isset($_SESSION)) {
    session_start();
}
require('adminLayout.php');
?>

<main>
    <article>
        <div class="article-section">
            <table id="customtable">
                <thead>
                    <b>
                        <td>S.N</td>
                    </b>
                    <td>Name</td>
                    <td>Action</td>

                </thead>
                <?php
                //selecting categories queries using pdo
                $category_db = $pdo->prepare("SELECT * FROM categories");

                $category_db->execute();
                //looping categories in list
                foreach ($category_db as $i => $item) { ?>
                    <tr>
                        <td> <?php echo ($i + 1); ?> </td>
                        <td><?php echo ($item['name']); ?></td>

                        <td> <a href="editCategory.php?id=<?php echo ($item['id']) ?>">Edit</a> || <a href="deleteCategory.php?id=<?php echo ($item['id']) ?>">Delete</a></td>
                    </tr>
                <?php
                }
                ?>

            </table>
        </div>
        </form>
    </article>
</main>