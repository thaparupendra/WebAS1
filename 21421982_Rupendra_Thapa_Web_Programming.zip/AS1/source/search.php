<?php
session_start();
if (isset($_SESSION['user'])) {
    include('userlayout.php'); 
}
else{
    include('layout.php'); 
}

 //fetching search keyword from url get method
 $search = $_GET['search']; 

//getting auction from its category
//Reference- Simple search using PHP and MySQL - Owlcation (no date). Available at: https://owlcation.com/stem/Simple-search-PHP-MySQL (Accessed: May 4, 2023). 
 $auctions = $pdo->prepare("SELECT * FROM auction WHERE (`title` LIKE '%".$search."%') OR (`description` LIKE '%".$search."%')");
 $auctions->execute();
?>

	<main>

		<h1>Latest Listings / Search Results / <?php echo $search; ?></h1>

		<ul class="productList">
            <?php 
            foreach ($auctions as $key => $auction) {   
            ?>
			<li>
            <?php echo '<img src="data:image/jpeg;base64,'.base64_encode($auction['image'] ).'" width="600"/>';?>
				<article>
					<h2><?php echo $auction['title'];  ?></h2>
					
					<p><?php echo $auction['description'];  ?>

					<p class="price">Current bid: £ <?php echo $auction['price'];  ?></p>
					<a href="auction.php?auction_id=<?php echo $auction['id'] ?>" class="more auctionLink">More &gt;&gt;</a>
				</article>
			</li>
            <?php
            }
            ?>
		
		</ul>
		<hr />

<?php
 include('footer.php');
?>