<?php
//starting admin session
session_start();
 include('adminlayout.php');
?>
	<main>

		<h1>Welcome to Admin Dashboard</h1>
	</main>
<?php
 include('footer.php');
?>