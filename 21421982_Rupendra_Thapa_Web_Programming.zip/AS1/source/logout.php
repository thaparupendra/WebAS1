<?php
//starting session and then logoutting
session_start();
session_unset();
session_destroy();
//redirecting to login page
header('location:login.php');
?>