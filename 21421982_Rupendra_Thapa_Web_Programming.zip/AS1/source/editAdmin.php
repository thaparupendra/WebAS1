<?php
//checking if session exist, if not then start
if (!isset($_SESSION)) {
    session_start();
}
require('adminLayout.php');
//statement to select category for edit and executing through GET method by its id
$sel_stmt = $pdo->prepare("SELECT * FROM users where id = :id");
$sel_stmt->execute($_GET);
//fetching the record
$data = $sel_stmt->fetch();

//checking for form submit through post method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
//updating seleted record
    $sel_stmt = $pdo->prepare("UPDATE users SET name=:name, email=:email, password=:password WHERE id=".$data['id']);
    $userdata = [

        'name' => $_POST['name'],
        'email' => $_POST['email'],
        'password' => password_hash($_POST['password'], PASSWORD_DEFAULT)
    ];
    if ($sel_stmt->execute($userdata)) {
        echo '<script> alert("Admin edited"); </script>';
    } else {
        echo '<script> alert("Admin Failed to edit"); </script>';
    }
}

?>

<main>
    <article>
        <div class="article-section">
            <form method="POST" action="">
                <div class="">
                    <h1> Edit Admin </h1>
                </div>
                <div class="">
                <label>Admin Name</label><br>
                <input type="text" placeholder="Admin Name" value="<?php echo($data['name']) ?>" name="name" required>

                <label>Admin Email</label><br>
                <input type="text" placeholder="Admin Email" value="<?php echo($data['email']) ?>" name="email" required>

                <label>Admin Password</label><br>
                <input type="password" placeholder="Admin Password" name="password" required>

                    <input type="submit" class="submit" value="Submit">
                </div>

        </div>
        </form>
    </article>
</main>