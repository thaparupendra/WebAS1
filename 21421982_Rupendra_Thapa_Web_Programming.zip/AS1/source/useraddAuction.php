<?php
//checking if session exist, if not then start
if (!isset($_SESSION)) {
    session_start();
}
//requiring layout 
require('userlayout.php');
//checking for form submit through POST method

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
    //statement to insert into database
    $stmt = $pdo->prepare("INSERT INTO `auction`(`title`, `description`, `categoryId`, `endDate`, `created_by`, `price`, `image`) VALUES (:title,:description,:categoryId,:endDate,:created_by,:price,'$image')
											");
  
    if ($stmt->execute($_POST)) {
        echo '<script> alert("Auction Added"); </script>';
    } else {
        echo '<script> alert("Auction not Added"); </script>';
    }
}
?>
<style>
    * {
            box-sizing: border-box;
        }

        input[type=text],
        input[type=date],
        input[type=file],
        input[type=number],
        input[type=password],
        select,
        textarea {
            width: 100%;
            padding: 14px;
            border: 1px solid;
            border-radius: 5px;
            resize: vertical;
        }

        label {
            padding: 10px 10px 1.px 0;
            display: inline-block;
        }

        input[type=submit] {
            background-color: #04AA6D;
            color: white;
            text-align: center;
            border: none;
            font-size: 25px !important;
            border-radius: 4px;
            cursor: pointer;
            margin-left:30px !important;

           
        }

        input[type=submit]:hover {
            background-color: green;
        }

        .container {
            border-radius: 5px;
            background-color: silver;
            padding: 20px;
        }
</style>
<main>
    <div>
        <h1> Add Your Auction Here </h1><br>

        <a href="" style="font-size: 20px;" > View Your Auction Here</a>
        <br>
        
    </div>

    


    <div class="container">
        <form method="POST" action="" enctype="multipart/form-data">

            <div class="">
                <label>Auction title</label><br>
                <input type="text" placeholder="Auction Title" name="title" required>

                <label>Auction description</label><br>
                <textarea placeholder="Auction description" rows="5" cols="3" name="description" required> </textarea>
<br>
                <label>Auction Category</label><br>
                <select name="categoryId" id="">
                    <?php
                    //selecting all categories
                    $categories = $pdo->prepare("SELECT * FROM categories");
                    $categories->execute();
                    // using loop to display categories in option
                    foreach ($categories as $cat) {
                    ?>
                        <option value="<?php echo ($cat['id']) ?>"><?php echo ($cat['name']) ?></option>
                    <?php
                    }
                    ?>
                </select>

                <label>Auction Image</label><br>
                <input type="file" placeholder="Auction Image" name="image" required>
<br>
                <label>Auction End Date</label><br>
                <input type="date" placeholder="Auction Date" name="endDate" required>

                <label>Auction Bid Starting Price </label><br>
                <input type="number" placeholder="Auction Price" name="price" required>

                <?php
                    $sel_stmt = $pdo->prepare("SELECT * FROM users where id =".$_SESSION['user']);
                    $sel_stmt->execute($_GET);
                    //fetching the record
                    $user = $sel_stmt->fetch();
                ?>

                <input type="hidden" name="created_by" value="<?php echo $user['name'] ?>">

                <input type="submit" class="submit" value="Submit">
            </div>


        </form>
    </div>

</main>