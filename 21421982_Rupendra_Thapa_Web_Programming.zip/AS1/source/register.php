<?php
//connecting databse
$pdo = new pdo("mysql:host=db;dbname=web", 'root','password');

//checking form submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  //statement to insert data on database
  $stmt = $pdo->prepare("INSERT INTO users SET
                  name= :name,
                  email= :email,
                  password= :password,
                  type= :type
                  ");
  $data=[

    'name' => $_POST['name'],
    'email' => $_POST['email'],
    'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
    'type' => "user"


  ];
    //executes a prepared statement
  if($stmt->execute($data)){
    echo '<script> alert("Successfully Registered"); </script>';
  }
  else{
    echo '<script> alert("Failed to Register"); </script>';
  }

   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register User</title>
  <link rel="stylesheet" href="ibuy.css">
  <link rel="stylesheet" href="login-register.css">
</head>
<body>
  
<form action="" method="POST">
  <div class="container">
    <h1>Register</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>

    <label for="name"><b>Name</b></label>
    <input type="text" placeholder="Full Name" name="name" id="name" required>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" id="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" id="psw" required>

    
    <hr>

    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
    <button type="submit" class="registerbtn">Register</button>
  </div>

  <div class="container signin">
    <p>Already have an account? <a href="login.php">Login in</a>.</p>
    <p>Back to Home <a href="index.php">Home</a>.</p>
  </div>
</form>
</body>
</html>

