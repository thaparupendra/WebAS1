<?php
//connecting database
$pdo = new pdo("mysql:host=db;dbname=web", 'root','password');
//checking if session exist
if (!isset($_SESSION['user'])) {
    session_destroy();
    //redirecting back to login page if user session not matched
    header('Location:login.php');
}
?>

<!DOCTYPE html>
<html>

<head>
	<title>ibuy Auctions</title>
	<link rel="stylesheet" href="ibuy.css" />
</head>

<body>
	<header>
		<h1><span class="i">i</span><span class="b">b</span><span class="u">u</span><span class="y">y</span></h1>

		<form action="search.php" method="get">
			<input type="text" name="search" placeholder="Search for anything" />
			<input type="submit" name="submit" value="Search" />
			<!-- <div class="login-section">

				<a href="logout.php"> Logout </a>
			

			</div> -->
		</form>



		<style>
			.login-section {
				font-size: 18px !important;
				float:right;
			}
		</style>
	</header>

	<nav>
		<ul>
		<li><a class="categoryLink" href="userindex.php" style="border: 2px; color:blue;">Home</a></li>
			<?php

			$categories = $pdo->prepare("SELECT * FROM categories");
			$categories->execute();
			foreach ($categories as $cat) {
				$href="category.php?category_id=".$cat['id'];
				?>

			<li><a class="categoryLink" href=" <?php echo $href; ?> "><?php echo ($cat['name']); ?> </a></li>
			<?php
			}
			?>
			
			<li><a class="categoryLink" href="useraddAuction.php" style="border: 2px; color:green;">Add Auction</a></li>
			<li><a class="categoryLink" href="logout.php" style="border: 2px; color:red;">Logout</a></li>
		</ul>
	</nav>
	<img src="banners/1.jpg" alt="Banner" />

	<style>
    * {
            box-sizing: border-box;
        }

        input[type=text],
        input[type=date],
        input[type=file],
        input[type=number],
        input[type=password],
        select,
        textarea {
            width: 100%;
            padding: 14px;
            border: 1px solid;
            border-radius: 5px;
            resize: vertical;
        }

        label {
            padding: 10px 10px 1.px 0;
            display: inline-block;
        }

        input[type=submit] {
            background-color: #04AA6D;
            color: white;
            text-align: center;
            border: none;
            font-size: 25px !important;
            border-radius: 4px;
            cursor: pointer;
            margin-left:30px !important;

           
        }

        input[type=submit]:hover {
            background-color: green;
        }

        .container {
            border-radius: 5px;
            background-color: silver;
            padding: 20px;
        }
</style>