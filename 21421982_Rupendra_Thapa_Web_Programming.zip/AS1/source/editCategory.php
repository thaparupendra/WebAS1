<?php
//checking if session exist, if not then start
if (!isset($_SESSION)) {
    session_start();
}
require('adminLayout.php');
//statement to select category for edit and executing through GET method by its id
$sel_stmt = $pdo->prepare("SELECT * FROM categories where id = :id");
$sel_stmt->execute($_GET);
//fetching the record
$row = $sel_stmt->fetch();

//checking for form submit through post method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
//updating seleted record
    $sel_stmt = $pdo->prepare("UPDATE categories SET name=:name WHERE id=".$row['id']);

    if ($sel_stmt->execute($_POST)) {
        echo '<script> alert("Category edited"); </script>';
    } else {
        echo '<script> alert("Category Failed to edit"); </script>';
    }
}

?>

<style>
    .article-section {
        display: inline-flex;
        padding: 20px;
        margin: 0;
        width: 100%;

    }
</style>
<main>
    <article>
        <div class="article-section">
            <form method="POST" action="">
                <div class="">
                    <h1> Edit Category </h1>
                </div>
                <div class="">
                    <label>Category Name</label>
                    <input type="text" placeholder="Category Name" name="name" value="<?php echo($row['name']) ?>" required>

                    <input type="submit" class="submit" value="Submit">
                </div>

        </div>
        </form>
    </article>
</main>