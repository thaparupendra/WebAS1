<?php
//connecting database
$pdo = new pdo("mysql:host=db;dbname=web", 'root','password');
//statement to delete from database
$del_stmt = $pdo->prepare("DELETE FROM categories WHERE id= :id");

if($del_stmt->execute($_GET)){
  //redirecting to view page
    header("Location:adminCategories.php?delete=1");
}

