<?php
	$pdo = new pdo("mysql:host=db;dbname=web", 'root', 'password');
?>
<!DOCTYPE html>
<html>

<head>
	<title>ibuy Auctions</title>
	<link rel="stylesheet" href="ibuy.css" />
</head>

<body>
	<header>
		<h1><span class="i">i</span><span class="b">b</span><span class="u">u</span><span class="y">y</span></h1>

		<form action="search.php" method="get">
			<input type="text" name="search" placeholder="Search for anything" />
			<input type="submit" name="submit" value="Search" />
			<!-- <div class="login-section">

				<a href="login.php"> Login </a>
				<a href="register.php">Register </a>

			</div> -->
		</form>



		<style>
			.login-section {
				font-size: 18px !important;
				float: right;
			}
		</style>
	</header>

	<nav>
		<ul>
		<li><a class="categoryLink" href="index.php" style="border: 2px; color:blue;">Home</a></li>
			<?php

			$categories = $pdo->prepare("SELECT * FROM categories");
			$categories->execute();
			foreach ($categories as $cat) {
				$href="category.php?category_id=".$cat['id'];
				?>

			<li><a class="categoryLink" href=" <?php echo $href; ?> "><?php echo ($cat['name']); ?> </a></li>
			<?php
			}
			?>
			
			<li><a class="categoryLink" href="login.php" style="border: 2px; color:red;">LOGIN</a></li>
		</ul>
	</nav>
	<img src="banners/1.jpg" alt="Banner" />