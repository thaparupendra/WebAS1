<?php
$pdo = new pdo("mysql:host=db;dbname=web", 'root', 'password');
//checking if session exist
// var_dump($_SESSION['admin']);
if (!isset($_SESSION['admin'])) {
    session_destroy();
    //redirecting back to login page if user session not matched
    header('Location:login.php');
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>ibuy Auctions</title>
    <link rel="stylesheet" href="ibuy.css" />
    <link rel="stylesheet" href="admin-css.css" />
</head>

<body>
    <header>
        <h1><span class="i">i</span><span class="b">b</span><span class="u">u</span><span class="y">y</span></h1>

        <form action="#">
            <input type="text" name="search" placeholder="Search for anything" />
            <input type="submit" name="submit" value="Search" />
         
        </form>
    </header>

    <nav>
        <ul>
            <li><a href="adminindex.php" style="color:aliceblue;">Home</a></li>

            <li><a href="#" style="color:aliceblue;">Category</a>

                <ul>
                    <li><a class="articleLink" href="adminCategories.php">View Categories</a></li>
                    <li><a class="articleLink" href="addCategory.php">Add New Category</a></li>

                </ul>
            </li>
            <li><a href="#" style="color:aliceblue;">Auction</a>

                <ul>
                    <li><a class="articleLink" href="adminAuction.php">View Auction</a></li>
                    <li><a class="articleLink" href="addAuction.php">Add Auction</a></li>

                </ul>
            </li>
            <li><a href="#" style="color:aliceblue;">Admin</a>

                <ul>
                    <li><a class="articleLink" href="manageAdmins.php">View Admin</a></li>
                    <li><a class="articleLink" href="addAdmin.php">Add Admin</a></li>

                </ul>
            </li>
            <li><a href="bidHistory.php" style="color:aliceblue;">User Bid History</a></li>
            <li><a href="logout.php" style="color:aliceblue;">Logout</a></li>
        </ul>
    </nav>