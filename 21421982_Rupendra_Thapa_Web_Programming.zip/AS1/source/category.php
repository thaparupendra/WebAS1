<?php
session_start();
if (isset($_SESSION['user'])) {
    include('userlayout.php'); 
}
else{
    include('layout.php'); 
}

 //fetching ID from url get method
 $category_id = $_GET['category_id']; 

 //getting selected category from its id and executing query
$category = $pdo->prepare("SELECT * FROM categories where id=". $category_id);
$category->execute();

//fetching the record
$row = $category->fetch();

//getting auction from its category
 $auctions = $pdo->prepare("SELECT * FROM auction WHERE categoryId=". $category_id);
 $auctions->execute();
?>

	<main>

		<h1>Latest Listings / Category / <?php echo $row['name']; ?></h1>

		<ul class="productList">
            <?php 
            foreach ($auctions as $key => $auction) {   
            ?>
			<li>
            <?php echo '<img src="data:image/jpeg;base64,'.base64_encode($auction['image'] ).'" width="600"/>';?>
				<article>
					<h2><?php echo $auction['title'];  ?></h2>
					<h3><?php echo $row['name']; ?></h3>
					<p><?php echo $auction['description'];  ?>

					<p class="price">Current bid: £ <?php echo $auction['price'];  ?></p>
					<a href="auction.php?auction_id=<?php echo $auction['id'] ?>" class="more auctionLink">More &gt;&gt;</a>
				</article>
			</li>
            <?php
            }
            ?>
		
		</ul>
		<hr />

<?php
 include('footer.php');
?>