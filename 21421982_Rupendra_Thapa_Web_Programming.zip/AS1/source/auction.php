<?php
//to prevent header error function obstart is used
// Reference : Prasanta BaidyaPrasanta, Stack Overflow. Available at: https://stackoverflow.com/questions/12448860/php-error-warning-cannot-modify-header-information-headers-already-sent-by (Accessed: May 2, 2023). 
ob_start();
session_start();
if (isset($_SESSION['user'])) {
    include('userlayout.php');
} else {
    include('layout.php');
}

//getting auction from URL GET METHOD by auction Id
$auctions = $pdo->prepare("SELECT * FROM auction WHERE id=" . $_GET['auction_id']);
//Executing the statement and fetching the record
$auctions->execute();
$auction = $auctions->fetch();

//checking if bid form submitted
if (isset($_POST['bid'])) {
    //getting required data auction user and price
    $auction_id = $auction['id'];
    $user_id = $_SESSION['user'];
    $auction_price = $auction['price'];
    $date = strtotime(date('Y-m-d'));
    $bid_amount = $_POST['bid_amount'];
//statement to insert user bids in database
    $bidstmt = $pdo->prepare("INSERT INTO user_bids SET user_id=$user_id,auction_id=$auction_id,bid_amount=$bid_amount,bid_date=$date");
//executing the statement
    if ($bidstmt->execute()) {
        $update_auction = $pdo->prepare("UPDATE auction SET price=$bid_amount WHERE id=" . $auction['id']);
        $update_auction->execute();
        header("Refresh:0");
        echo '<script> alert("Bid Placed Sucessfully.."); </script>';
    }
}


//checking if review form submitted
if (isset($_POST['submit_review'])) {
    //getting required data auction user and review
    $auction_id = $auction['id'];
    $user_id = $_SESSION['user'];
    //selecting currently active user for posting review
    $user = $pdo->prepare("SELECT * FROM users WHERE id=" . $user_id);
    $user->execute();
    $user = $user->fetch();
    $username = $user['name'];
    $review = $_POST['review'];
    $date = date('Y-m-d H:i:s');
//statement to insert reviews in database
    $bidstmt = $pdo->prepare("INSERT INTO reviews SET user_name='$username',auction_id=$auction_id,review='$review',date='$date'");

    if ($bidstmt->execute()) {
        header("Refresh:0");
        echo '<script> alert("Review Posted Sucessfully.."); </script>';
    }
}

?>
<main>

    <h1>Latest Listings / Auction / <?php echo $auction['title'];  ?>

        <h1>Product Page</h1>
        <article class="product">
<!-- Reference: Arian FaurtoshArian Faurtosh 17.8k2121 gold badges7575 silver badges115115 bronze badges (1960) PHP display image blob from mysql, Stack Overflow. Available at: https://stackoverflow.com/questions/20556773/php-display-image-blob-from-mysql (Accessed: May 5, 2023). -->
            <?php echo '<img src="data:image/jpeg;base64,' . base64_encode($auction['image']) . '" width="500"/>'; ?>
            <section class="details">
                <h2><?php echo $auction['title'];  ?></h2>
                <?php
                //getting auction category from auction category id
                $category = $pdo->prepare("SELECT * FROM categories WHERE id=" . $auction['categoryId']);
                //executing and fetching required category
                $category->execute();
                $auction_category = $category->fetch();
                ?>
                <h3><?php echo $auction_category['name'];  ?></h3>
                <p>Auction created by <a href="#"><?php echo $auction['created_by']; ?></a></p>
                <p class="price">Current bid: £ <?php echo $auction['price']; ?></p>

                <?php
                //code to calculate remaining date from expiry date
                //reference: Tomasa and Droopsnoot (2018) PHP calculating remaining time between two dates, SitePoint Forums | Web Development &amp; Design Community. Available at: https://www.sitepoint.com/community/t/php-calculating-remaining-time-between-two-dates/299857 (Accessed: May 3, 2023). 
                $auction_end_date = $auction['endDate'];
                $today_date = date('Y-m-d');
                $enddate = strtotime($auction_end_date);
                $currentdate = strtotime($today_date);
                //subtracting two dates to check time is expired or not
                $date_difference =  $enddate - $currentdate;
                if ($date_difference < 1) {
                    echo ("Auction Bidding Time is Expired..");
                } else {
                    $final_date = new DateTime($auction_end_date);
                    $current_datetime = new DateTime();
                    $time_interval = $final_date->diff($current_datetime);
                    echo '<time>Time left:' . $time_interval->format("%a days, %h h, %i min, %s sec") . '</time>';
                }

                ?>
                <?php
                if (isset($_SESSION['user'])) {
                    if ($date_difference > 1) {
                       
                    
                ?>
                    <form action="#" class="bid" method="POST">
                        <input type="text" name="bid_amount" placeholder="Enter bid amount" required />
                        <input name="bid" type="submit" value="Place bid" />
                    </form>
                <?php
                } }
                else {
                    echo ('<a href="login.php"> Please Login to Place a Bid.</a>');
                }
                ?>

            </section>
            <section class="description">
                <p>
                    <?php echo $auction['description'];  ?>

                </p>
            </section>

            <section class="reviews">
                <h2>Reviews of Users </h2>
                <ul>
                    <?php
                    //fetching all review of auction from database and executing query
                    $reviews = $pdo->prepare("SELECT * FROM reviews WHERE auction_id=" . $auction['id']);
                    $reviews->execute();
                    foreach ($reviews as $review) {
                    ?>
                        <li><strong><?php echo $review['user_name']; ?> said </strong><?php  echo $review['review']; ?><em><?php  echo $review['date']; ?></em></li>

                    <?php
                    }
                    ?>

                </ul>

                <form method="POST">
                    <label>Add your review</label> <textarea name="review"></textarea>

                    <input type="submit" name="submit_review" value="Add Review" />
                </form>
            </section>
        </article>

        <hr />
        <!-- <h1>Sample Form</h1>

	<form action="#">
		<label>Text box</label> <input type="text" />
		<label>Another Text box</label> <input type="text" />
		<input type="checkbox" /> <label>Checkbox</label>
		<input type="radio" /> <label>Radio</label>
		<input type="submit" value="Submit" />

	</form> -->



        <?php
        include('footer.php');
        ?>