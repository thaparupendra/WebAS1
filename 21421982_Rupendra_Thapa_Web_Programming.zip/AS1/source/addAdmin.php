<?php
//checking if session exist, if not then start
if (!isset($_SESSION)) {
    session_start();
}
//requiring layout 
require('adminlayout.php');
//checking for form submit through POST method

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //statement to insert users into database
    $userstmt = $pdo->prepare("INSERT INTO users SET
    name= :name,
    email= :email,
    password= :password,
    type= :type
    ");
    $userdata = [

        'name' => $_POST['name'],
        'email' => $_POST['email'],
        'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
        'type' => "admin"
    ];

    
  
    if ($userstmt->execute($userdata)) {
        echo '<script> alert("Admin Added"); </script>';
    } else {
        echo '<script> alert("Admin not Added"); </script>';
    }
}
?>

<main>
    <div>
        <h1> Add Admin Here </h1><br>
    </div>



    <div class="container">
        <form method="POST" action="" enctype="multipart/form-data">

            <div class="">
                <label>Admin Name</label><br>
                <input type="text" placeholder="Admin Name" name="name" required>

                <label>Admin Email</label><br>
                <input type="text" placeholder="Admin Email" name="email" required>

                <label>Admin Password</label><br>
                <input type="password" placeholder="Admin Password" name="password" required>

                
                <input type="submit" class="submit" value="Submit">
            </div>


        </form>
    </div>

</main>