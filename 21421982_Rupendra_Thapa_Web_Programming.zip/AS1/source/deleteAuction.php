<?php
//connecting database
$pdo = new pdo("mysql:host=db;dbname=web", 'root','password');
//statement to delete auction from database
$del_stmt = $pdo->prepare("DELETE FROM auction WHERE id= :id");

if($del_stmt->execute($_GET)){
  //redirecting to view page
    header("Location:adminAuction.php?delete=1");
}

